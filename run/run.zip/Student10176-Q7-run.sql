select * from filtered_predcalc_q7;
